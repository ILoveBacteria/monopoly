public class Road extends Area {
    public Road(int areaNumber) {
        super(areaNumber, false);
        super.setRentPrice(100);
    }
}