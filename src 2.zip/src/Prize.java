public class Prize extends Area {
    public Prize(int areaNumber) {
        super(areaNumber, false);
    }
}