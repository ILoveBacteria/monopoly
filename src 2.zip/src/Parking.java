public class Parking extends Area {
    public Parking(int areaNumber) {
        super(areaNumber, false);
    }
}