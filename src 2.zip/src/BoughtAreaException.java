public class BoughtAreaException extends Exception{
    public BoughtAreaException() {
        System.out.println("BoughtAreaException");
    }
}
