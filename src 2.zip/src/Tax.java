public class Tax extends Area {
    public Tax(int areaNumber) {
        super(areaNumber, false);
    }
}