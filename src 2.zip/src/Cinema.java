public class Cinema extends Area {
    public Cinema(int areaNumber) {
        super(areaNumber, true);
        super.setBuyPrice(200);
    }
}