public class Prison extends Area {
    public Prison(int areaNumber) {
        super(areaNumber, false);
        super.setRentPrice(10);
    }
}
