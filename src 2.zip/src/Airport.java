public class Airport extends Area {
    public Airport(int areaNumber) {
        super(areaNumber, false);
    }
}